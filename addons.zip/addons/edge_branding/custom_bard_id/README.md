# Custom_Bard_Id

> Custom_Bard_Id is a Statamic addon that does something pretty neat.

## Features

This addon does:

- This
- And this
- And even this

## How to Install

You can install this addon via Composer:

``` bash
composer require edge_branding/custom_bard_id
```

## How to Use

Here's where you can explain how to use this wonderful addon.
