<?php

namespace EdgeBranding\CustomBardId\Marks;

use Tiptap\Core\Mark;
use Tiptap\Utils\HTML;

class CustomId extends Mark
{
  // The name of the mark. This is what you will reference in Tiptap.
  public static $name = 'custom_id';

  // Add any additional options you need (like custom HTMLAttributes).
  public function addOptions()
  {
    return [
      'HTMLAttributes' => [],
    ];
  }

  // This defines how to parse the HTML when it is loaded from the saved content.
  public function parseHTML()
  {
    return [
      [
        // Match any element with an 'id' attribute and parse it as a custom_id mark
        'tag' => '*',
        'getAttrs' => function ($DOMNode) {
          return isset($DOMNode->id) ? ['id' => $DOMNode->id] : false;
        },
      ],
    ];
  }

  // This function will render the HTML when the content is being saved or displayed.
  public function renderHTML($mark, $HTMLAttributes = [])
  {
    // Merge any HTMLAttributes passed in with the mark's options
    $HTMLAttributes = HTML::mergeAttributes($this->options['HTMLAttributes'], $HTMLAttributes);

    // Check if 'id' is in the attributes and if so, output the corresponding HTML
    if (isset($mark['attrs']['id'])) {
      $HTMLAttributes['id'] = $mark['attrs']['id']; // Ensure the 'id' attribute is added
    }

    // Return the element that should wrap the content, in this case a span
    return [
      'span', // The element to use (you can change this to any other element, e.g., 'div', etc.)
      $HTMLAttributes, // Merge the 'id' attribute here
      0,
    ];
  }
}
