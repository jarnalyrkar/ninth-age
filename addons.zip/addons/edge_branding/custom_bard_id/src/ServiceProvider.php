<?php

namespace EdgeBranding\CustomBardId;

use Statamic\Providers\AddonServiceProvider;
use Statamic\Fieldtypes\Bard\Augmentor;
use \EdgeBranding\CustomBardId\Marks\CustomId;

class ServiceProvider extends AddonServiceProvider
{
  protected $vite = ['resources/js/cp.js'];

  public function bootAddon()
  {
    // Register the CustomId extension
    Augmentor::addExtension('custom_id', new CustomId);
  }
}
