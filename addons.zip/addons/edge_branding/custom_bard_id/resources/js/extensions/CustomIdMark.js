const { Mark, mergeAttributes } = Statamic.$bard.tiptap.core;


export const CustomIdMark = Mark.create({
  name: 'customId',

  addOptions() {
    return {
      HTMLAttributes: {},
    }
  },

  parseHTML() {
    return [
      {
        tag: 'span',
        getAttrs: node => {
          // Check if the span has an id attribute
          return node.id ? { id: node.id } : null
        },
      },
    ]
  },

  renderHTML({ HTMLAttributes }) {
    // Render the span with the id attribute from HTMLAttributes
    return ['span', mergeAttributes(this.options.HTMLAttributes, HTMLAttributes), 0]
  },

  addCommands() {
    return {
      setCustomId: (id) => ({ commands }) => {
        return commands.setMark(this.name, { id })
      },
      toggleCustomId: () => ({ commands }) => {
        return commands.toggleMark(this.name)
      },
      unsetCustomId: () => ({ commands }) => {
        return commands.unsetMark(this.name)
      },
    }
  },
})