import { CustomIdMark } from "./extensions/CustomIdMark";

Statamic.$bard.addExtension(() => {
  return [
    CustomId,  // Register the customId extension here
  ]
})