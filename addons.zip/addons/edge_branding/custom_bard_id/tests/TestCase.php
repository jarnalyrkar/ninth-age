<?php

namespace EdgeBranding\CustomBardId\Tests;

use EdgeBranding\CustomBardId\ServiceProvider;
use Statamic\Testing\AddonTestCase;

abstract class TestCase extends AddonTestCase
{
    protected string $addonServiceProvider = ServiceProvider::class;
}
